import { useQuery } from "@tanstack/react-query";
import StatusOverview from "@/components/dashboard/StatusOverview";
import EntropyVisualization from "@/components/dashboard/EntropyVisualization";
import KeyGenerationMetrics from "@/components/dashboard/KeyGenerationMetrics";
import KeyManagementPanel from "@/components/dashboard/KeyManagementPanel";
import SecurityConsole from "@/components/dashboard/SecurityConsole";

export default function Dashboard() {
  // Fetch security status
  const { data: securityStatus } = useQuery({
    queryKey: ['/api/security/status'],
  });
  
  // Fetch active keys
  const { data: activeKeys } = useQuery({
    queryKey: ['/api/keys/active'],
  });
  
  // Fetch threat alerts
  const { data: threatAlerts } = useQuery({
    queryKey: ['/api/security/threats'],
  });
  
  // Fetch neural network status
  const { data: neuralNetworkStatus } = useQuery({
    queryKey: ['/api/neural/status'],
  });
  
  // Fetch entropy data
  const { data: entropyData } = useQuery({
    queryKey: ['/api/keys/entropy'],
  });
  
  // Fetch key metrics
  const { data: keyMetrics } = useQuery({
    queryKey: ['/api/keys/metrics'],
  });
  
  // Fetch all keys
  const { data: allKeys } = useQuery({
    queryKey: ['/api/keys/all'],
  });
  
  // Fetch console logs
  const { data: consoleLogs } = useQuery({
    queryKey: ['/api/logs/console'],
  });

  return (
    <div>
      <h1 className="text-2xl font-semibold text-slate-900">Security Dashboard</h1>
      
      <div className="py-4">
        {/* Status Overview Section */}
        <StatusOverview 
          securityStatus={securityStatus} 
          activeKeys={activeKeys} 
          threatAlerts={threatAlerts} 
          neuralNetworkStatus={neuralNetworkStatus}
        />
        
        {/* Key Management and Neural Network Section */}
        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
          <EntropyVisualization 
            entropyData={entropyData} 
            className="lg:col-span-2" 
          />
          <KeyGenerationMetrics keyMetrics={keyMetrics} />
        </div>
        
        {/* Key Management Panel */}
        <KeyManagementPanel keys={allKeys} />
        
        {/* Security Console */}
        <SecurityConsole logs={consoleLogs} />
      </div>
    </div>
  );
}
