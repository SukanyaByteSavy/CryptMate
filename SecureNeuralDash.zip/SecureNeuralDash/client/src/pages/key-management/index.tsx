import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import KeyManagementPanel from "@/components/dashboard/KeyManagementPanel";

export default function KeyManagement() {
  // Fetch all keys
  const { data: allKeys } = useQuery({
    queryKey: ['/api/keys/all'],
  });

  return (
    <div>
      <h1 className="text-2xl font-semibold text-slate-900">Key Management</h1>
      
      <div className="py-4">
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-medium text-slate-900">Neural-Enhanced Key Management</h2>
                <p className="text-slate-500 mt-1">
                  Generate and manage AES-256 encryption keys with neural network enhancement
                </p>
              </div>
              <Button>Generate New Key</Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Use the same KeyManagementPanel from the dashboard */}
        <KeyManagementPanel keys={allKeys} />
      </div>
    </div>
  );
}
