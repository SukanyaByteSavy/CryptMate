import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Network, Activity, Lock } from "lucide-react";

export default function NeuralNetwork() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-slate-900">Neural Network</h1>
      
      <div className="py-4">
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="bg-indigo-100 p-3 rounded-lg">
                  <Brain className="h-10 w-10 text-indigo-600" />
                </div>
                <div className="ml-4">
                  <h2 className="text-xl font-medium text-slate-900">Neural Cryptography Network</h2>
                  <p className="text-slate-500">Status: <span className="text-green-600 font-medium">Active</span></p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-slate-500">Last trained</div>
                <div className="text-sm font-medium">April 11, 2023 at 23:17:42</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue="overview">
          <TabsList className="w-full">
            <TabsTrigger value="overview" className="flex-1">
              <Activity className="mr-2 h-4 w-4" />
              Network Overview
            </TabsTrigger>
            <TabsTrigger value="architecture" className="flex-1">
              <Network className="mr-2 h-4 w-4" />
              Architecture
            </TabsTrigger>
            <TabsTrigger value="performance" className="flex-1">
              <Lock className="mr-2 h-4 w-4" />
              Cryptographic Performance
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Network Status</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Training Progress</span>
                        <span className="text-sm text-slate-500">15,432 iterations</span>
                      </div>
                      <Progress value={87} className="h-2 mt-2" />
                    </div>
                    <div>
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Model Accuracy</span>
                        <span className="text-sm text-slate-500">99.7%</span>
                      </div>
                      <Progress value={99.7} className="h-2 mt-2" indicatorClassName="bg-green-500" />
                    </div>
                    <div>
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Entropy Generation</span>
                        <span className="text-sm text-slate-500">HIGH</span>
                      </div>
                      <Progress value={94} className="h-2 mt-2" indicatorClassName="bg-indigo-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Recursion Depth</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-5 gap-2">
                      {[1, 2, 3, 4, 5].map((level) => (
                        <div key={level} className={`border p-3 rounded-lg text-center ${level <= 4 ? 'bg-indigo-50 border-indigo-200' : 'bg-slate-50 border-slate-200'}`}>
                          <div className={`text-xl font-bold ${level <= 4 ? 'text-indigo-600' : 'text-slate-400'}`}>{level}</div>
                          <div className="text-xs mt-1">{level <= 4 ? 'Active' : 'Inactive'}</div>
                        </div>
                      ))}
                    </div>
                    <p className="text-sm text-slate-600">
                      Current recursion depth: <span className="font-medium">Level 4</span> (Advanced protection)
                    </p>
                    <p className="text-sm text-slate-500">
                      Neural network recursion depth determines the complexity of the encryption patterns and resistance to attacks.
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="md:col-span-2">
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Network Activity</h3>
                  <div className="h-64 flex items-center justify-center border border-dashed border-slate-300 rounded-lg bg-slate-50">
                    <p className="text-slate-500">Neural network activity visualization will appear here</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="architecture">
            <Card className="mt-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">Neural Network Architecture</h3>
                <div className="h-96 flex items-center justify-center border border-dashed border-slate-300 rounded-lg bg-slate-50">
                  <p className="text-slate-500">Neural network architecture diagram will appear here</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="performance">
            <Card className="mt-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">Cryptographic Performance</h3>
                <div className="h-96 flex items-center justify-center border border-dashed border-slate-300 rounded-lg bg-slate-50">
                  <p className="text-slate-500">Cryptographic performance metrics will appear here</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
