import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart2, TrendingUp, Shield, AlertCircle } from "lucide-react";

export default function Analytics() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-slate-900">Analytics</h1>
      
      <div className="py-4">
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-lg">
                <BarChart2 className="h-10 w-10 text-primary" />
              </div>
              <div className="ml-4">
                <h2 className="text-xl font-medium text-slate-900">Security Analytics Dashboard</h2>
                <p className="text-slate-500">Monitor encryption performance and security metrics</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue="overview">
          <TabsList className="w-full">
            <TabsTrigger value="overview" className="flex-1">
              <TrendingUp className="mr-2 h-4 w-4" />
              Performance Overview
            </TabsTrigger>
            <TabsTrigger value="security" className="flex-1">
              <Shield className="mr-2 h-4 w-4" />
              Security Metrics
            </TabsTrigger>
            <TabsTrigger value="threats" className="flex-1">
              <AlertCircle className="mr-2 h-4 w-4" />
              Threat Analysis
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
              <Card className="lg:col-span-2">
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Encryption Performance</h3>
                  <div className="h-80 flex items-center justify-center border border-dashed border-slate-300 rounded-lg bg-slate-50">
                    <p className="text-slate-500">Performance chart will appear here</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Key Generation Metrics</h3>
                  <div className="h-64 flex items-center justify-center border border-dashed border-slate-300 rounded-lg bg-slate-50">
                    <p className="text-slate-500">Key generation metrics will appear here</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Neural Network Performance</h3>
                  <div className="h-64 flex items-center justify-center border border-dashed border-slate-300 rounded-lg bg-slate-50">
                    <p className="text-slate-500">Neural network metrics will appear here</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="security">
            <Card className="mt-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">Security Metrics</h3>
                <div className="h-96 flex items-center justify-center border border-dashed border-slate-300 rounded-lg bg-slate-50">
                  <p className="text-slate-500">Security metrics will appear here</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="threats">
            <Card className="mt-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">Threat Analysis</h3>
                <div className="h-96 flex items-center justify-center border border-dashed border-slate-300 rounded-lg bg-slate-50">
                  <p className="text-slate-500">Threat analysis will appear here</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
