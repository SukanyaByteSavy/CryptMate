import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, User, Shield, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function Settings() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-slate-900">Settings</h1>
      
      <div className="py-4">
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-lg">
                <SettingsIcon className="h-10 w-10 text-primary" />
              </div>
              <div className="ml-4">
                <h2 className="text-xl font-medium text-slate-900">System Settings</h2>
                <p className="text-slate-500">Configure your security and encryption preferences</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue="general">
          <TabsList className="w-full">
            <TabsTrigger value="general" className="flex-1">
              <User className="mr-2 h-4 w-4" />
              Account Settings
            </TabsTrigger>
            <TabsTrigger value="security" className="flex-1">
              <Shield className="mr-2 h-4 w-4" />
              Security Settings
            </TabsTrigger>
            <TabsTrigger value="system" className="flex-1">
              <Server className="mr-2 h-4 w-4" />
              System Configuration
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="general">
            <Card className="mt-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">Account Settings</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="col-span-1">
                      <Label className="text-sm font-medium">Username</Label>
                      <div className="mt-1 flex rounded-md shadow-sm">
                        <input
                          type="text"
                          className="flex-1 min-w-0 block w-full px-3 py-2 rounded-md border border-slate-300 text-sm"
                          placeholder="admin"
                          value="admin"
                          disabled
                        />
                      </div>
                    </div>
                    <div className="col-span-1">
                      <Label className="text-sm font-medium">Email Address</Label>
                      <div className="mt-1 flex rounded-md shadow-sm">
                        <input
                          type="email"
                          className="flex-1 min-w-0 block w-full px-3 py-2 rounded-md border border-slate-300 text-sm"
                          placeholder="admin@example.com"
                          value="admin@example.com"
                        />
                      </div>
                    </div>
                    <div className="col-span-1">
                      <Label className="text-sm font-medium">Role</Label>
                      <div className="mt-1 flex rounded-md shadow-sm">
                        <input
                          type="text"
                          className="flex-1 min-w-0 block w-full px-3 py-2 rounded-md border border-slate-300 text-sm"
                          placeholder="Security Admin"
                          value="Security Admin"
                          disabled
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-5">
                    <div className="flex justify-end">
                      <Button>Save Changes</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="security">
            <Card className="mt-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">Security Settings</h3>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-base font-medium mb-2">Authentication</h4>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">Two-factor authentication</Label>
                          <p className="text-sm text-slate-500">Add an extra layer of security to your account</p>
                        </div>
                        <Switch />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">Session timeout</Label>
                          <p className="text-sm text-slate-500">Automatically log out after inactivity</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-base font-medium mb-2">Neural Cryptography</h4>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">Advanced neural protection</Label>
                          <p className="text-sm text-slate-500">Use neural networks for stronger encryption</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">Auto-renewal of keys</Label>
                          <p className="text-sm text-slate-500">Automatically renew keys before expiration</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-5">
                    <div className="flex justify-end">
                      <Button>Save Security Settings</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="system">
            <Card className="mt-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">System Configuration</h3>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-base font-medium mb-2">Performance</h4>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">High-performance mode</Label>
                          <p className="text-sm text-slate-500">Optimize for speed at the cost of higher resource usage</p>
                        </div>
                        <Switch />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">Background processing</Label>
                          <p className="text-sm text-slate-500">Allow encryption tasks to run in the background</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-base font-medium mb-2">Logging</h4>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">Detailed logs</Label>
                          <p className="text-sm text-slate-500">Keep detailed logs of all security operations</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">Log retention period</Label>
                          <p className="text-sm text-slate-500">How long to keep security logs</p>
                        </div>
                        <select className="form-select text-sm border-slate-300 rounded-md">
                          <option>30 days</option>
                          <option>60 days</option>
                          <option>90 days</option>
                          <option>180 days</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-5">
                    <div className="flex justify-end">
                      <Button>Save System Settings</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
