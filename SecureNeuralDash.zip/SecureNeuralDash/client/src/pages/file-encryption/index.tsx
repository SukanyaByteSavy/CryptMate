import { useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { FileIcon, UploadCloud, Lock, Unlock, Shield, AlertCircle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface EncryptedFile {
  id: string;
  filename: string;
  originalFilename: string;
  encryptionMethod: string;
  encryptionKeyId: string;
  size: number;
  encryptedAt: string;
}

export default function FileEncryption() {
  const [file, setFile] = useState<File | null>(null);
  const [encryptedFile, setEncryptedFile] = useState<File | null>(null);
  const [encryptionMethod, setEncryptionMethod] = useState("aes-neural");
  const [encryptionKey, setEncryptionKey] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [encryptedFiles, setEncryptedFiles] = useState<EncryptedFile[]>([]);
  const [keyVerified, setKeyVerified] = useState(false);
  const [activeTab, setActiveTab] = useState("encrypt");
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Reference to the decrypt tab trigger
  const decryptTabRef = useRef<HTMLButtonElement>(null);

  const handleEncrypt = async () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a file to encrypt",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsUploading(true);
      
      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 95) {
            clearInterval(interval);
            return 95;
          }
          return prev + 5;
        });
      }, 100);
      
      // Simulate upload completion after 2 seconds
      setTimeout(() => {
        clearInterval(interval);
        setUploadProgress(100);
        setIsUploading(false);
        setIsProcessing(true);
        
        // Simulate processing
        setTimeout(() => {
          setIsProcessing(false);
          
          // Generate a strong encryption key
          const encryptionKeyId = `KEY-${Math.floor(Math.random() * 1000000)}`;
          const generatedEncryptionKey = `${encryptionKeyId}-${Math.random().toString(36).slice(2, 10)}${Math.random().toString(36).slice(2, 10)}`;
          
          // Create a new encrypted file record
          const newEncryptedFile: EncryptedFile = {
            id: `file-${Date.now()}`,
            filename: `${file.name}.enc`,
            originalFilename: file.name,
            encryptionMethod: encryptionMethod === 'aes-neural' ? 'AES-256 Neural Enhanced' : 'AES-256 Standard',
            encryptionKeyId: encryptionKeyId,
            size: file.size,
            encryptedAt: new Date().toString()
          };
          
          setEncryptedFiles(prev => [...prev, newEncryptedFile]);
          setGeneratedKey(generatedEncryptionKey);
          
          toast({
            title: "File encrypted successfully",
            description: `${file.name} has been encrypted using ${encryptionMethod === 'aes-neural' ? 'AES-256 Neural Enhanced' : 'AES-256 Standard'}. The file is now secured and cannot be opened without proper decryption.`,
          });
          
          // Clear file input
          setFile(null);
          
        }, 1500);
      }, 2000);
    } catch (error) {
      setIsUploading(false);
      setIsProcessing(false);
      toast({
        title: "Encryption failed",
        description: "There was an error encrypting your file",
        variant: "destructive",
      });
    }
  };

  const handleDecrypt = async () => {
    if (!encryptedFile) {
      toast({
        title: "No file selected",
        description: "Please select an encrypted file to decrypt",
        variant: "destructive",
      });
      return;
    }
    
    if (!encryptionKey) {
      toast({
        title: "No encryption key provided",
        description: "Please provide a valid encryption key",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsProcessing(true);
      
      // Simulate decryption process
      setTimeout(() => {
        setIsProcessing(false);
        
        // Verify key format (this is a simulation)
        if (!encryptionKey.includes('KEY-') || encryptionKey.length < 20) {
          setKeyVerified(false);
          toast({
            title: "Decryption failed",
            description: "Invalid encryption key format. Please use the key that was provided when you encrypted the file.",
            variant: "destructive",
          });
          return;
        }
        
        setKeyVerified(true);
        toast({
          title: "File decrypted successfully",
          description: `The file has been decrypted and is now available for viewing.`,
        });
      }, 2000);
    } catch (error) {
      setIsProcessing(false);
      toast({
        title: "Decryption failed",
        description: "There was an error decrypting your file",
        variant: "destructive",
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };
  
  const handleEncryptedFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      // Check if file has .enc extension
      const fileName = e.target.files[0].name;
      if (!fileName.endsWith('.enc')) {
        toast({
          title: "Invalid file format",
          description: "Please select a file with .enc extension",
          variant: "destructive",
        });
        return;
      }
      
      setEncryptedFile(e.target.files[0]);
      setKeyVerified(false); // Reset key verification when file changes
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-semibold text-slate-900">File Encryption</h1>
      
      <Alert className="mb-4 mt-2">
        <Shield className="h-4 w-4" />
        <AlertTitle>Secure File Protection</AlertTitle>
        <AlertDescription>
          Files are encrypted with AES-256 and neural network enhancement. Encrypted files cannot be opened without proper decryption using a valid key.
        </AlertDescription>
      </Alert>
      
      <div className="py-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full">
            <TabsTrigger value="encrypt" className="flex-1">
              <Lock className="mr-2 h-4 w-4" />
              Encrypt File
            </TabsTrigger>
            <TabsTrigger ref={decryptTabRef} value="decrypt" className="flex-1">
              <Unlock className="mr-2 h-4 w-4" />
              Decrypt File
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="encrypt">
            <Card>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Encryption Method</h3>
                    <Select value={encryptionMethod} onValueChange={setEncryptionMethod}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select encryption method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="aes-neural">AES-256 Neural Enhanced</SelectItem>
                        <SelectItem value="aes-standard">AES-256 Standard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-2">Select File</h3>
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 flex flex-col items-center">
                      {file ? (
                        <div className="flex items-center space-x-4">
                          <FileIcon className="h-12 w-12 text-primary" />
                          <div>
                            <p className="text-sm font-medium">{file.name}</p>
                            <p className="text-xs text-slate-500">{(file.size / 1024).toFixed(2)} KB</p>
                          </div>
                        </div>
                      ) : (
                        <>
                          <UploadCloud className="h-12 w-12 text-slate-400 mb-4" />
                          <p className="text-sm text-slate-500 mb-2">Drag and drop file here, or click to select</p>
                          <p className="text-xs text-slate-400">Supported formats: All file types</p>
                        </>
                      )}
                      <Input 
                        type="file" 
                        className="hidden"
                        id="file-upload" 
                        onChange={handleFileChange}
                      />
                      <Button 
                        variant="outline" 
                        onClick={() => document.getElementById('file-upload')?.click()}
                        className="mt-4"
                      >
                        Select File
                      </Button>
                    </div>
                  </div>
                  
                  {(isUploading || isProcessing) && (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">
                          {isUploading ? 'Uploading...' : 'Processing...'}
                        </span>
                        <span className="text-sm text-slate-500">
                          {isUploading ? `${uploadProgress}%` : ''}
                        </span>
                      </div>
                      <Progress value={uploadProgress} className="h-2" />
                    </div>
                  )}
                  
                  {generatedKey && (
                    <Alert className="border-green-500 bg-green-50">
                      <Shield className="h-4 w-4 text-green-500" />
                      <AlertTitle className="text-green-600">File Encryption Key</AlertTitle>
                      <AlertDescription className="text-green-600">
                        <div className="font-mono bg-slate-100 p-2 rounded border border-green-200 mt-1 break-all relative">
                          {generatedKey}
                          <Button 
                            variant="ghost"
                            size="sm"
                            className="absolute top-1 right-1 text-xs bg-green-100 hover:bg-green-200"
                            onClick={() => {
                              navigator.clipboard.writeText(generatedKey);
                              toast({
                                title: "Key copied",
                                description: "Encryption key copied to clipboard"
                              });
                            }}
                          >
                            Copy
                          </Button>
                        </div>
                        <p className="mt-2 text-sm text-slate-600">
                          Keep this key safe! You will need it to decrypt your file later.
                        </p>
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="flex justify-end">
                    <Button 
                      onClick={handleEncrypt}
                      disabled={!file || isUploading || isProcessing}
                    >
                      <Lock className="mr-2 h-4 w-4" />
                      Encrypt File
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {encryptedFiles.length > 0 && (
              <div className="mt-6">
                <h3 className="text-lg font-medium mb-4">Recently Encrypted Files</h3>
                <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                  <div className="space-y-4">
                    {encryptedFiles.map((encFile) => (
                      <div key={encFile.id} className="flex items-center justify-between border-b border-slate-200 pb-4">
                        <div className="flex items-center space-x-3">
                          <Lock className="h-5 w-5 text-primary" />
                          <div>
                            <p className="text-sm font-medium">{encFile.filename}</p>
                            <p className="text-xs text-slate-500">
                              {encFile.encryptionMethod} • {(encFile.size / 1024).toFixed(2)} KB
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="text-xs text-slate-500">
                            Encrypted: {encFile.encryptedAt}
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-xs flex items-center"
                            onClick={() => {
                              // Switch to decrypt tab
                              setActiveTab("decrypt");
                              
                              // Simulate selecting this file for decryption
                              setTimeout(() => {
                                setEncryptedFile(new File([], encFile.filename, {
                                  type: 'application/octet-stream'
                                }));
                              }, 100);
                            }}
                          >
                            <Unlock className="h-3 w-3 mr-1" />
                            Decrypt
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="decrypt">
            <Card>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Select Encrypted File</h3>
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 flex flex-col items-center">
                      {encryptedFile ? (
                        <div className="flex items-center space-x-4">
                          <Lock className="h-12 w-12 text-primary" />
                          <div>
                            <p className="text-sm font-medium">{encryptedFile.name}</p>
                            <p className="text-xs text-slate-500">{(encryptedFile.size / 1024).toFixed(2)} KB</p>
                          </div>
                        </div>
                      ) : (
                        <>
                          <UploadCloud className="h-12 w-12 text-slate-400 mb-4" />
                          <p className="text-sm text-slate-500 mb-2">Drag and drop encrypted file here, or click to select</p>
                          <p className="text-xs text-slate-400">Supported formats: .enc files</p>
                        </>
                      )}
                      <Input 
                        type="file" 
                        className="hidden"
                        id="encrypted-file-upload" 
                        onChange={handleEncryptedFileChange}
                      />
                      <Button 
                        variant="outline" 
                        onClick={() => document.getElementById('encrypted-file-upload')?.click()}
                        className="mt-4"
                      >
                        Select Encrypted File
                      </Button>
                    </div>
                  </div>
                  
                  {encryptedFile && (
                    <div>
                      <h3 className="text-lg font-medium mb-2">Decryption Key</h3>
                      <div className="flex space-x-2">
                        <Input 
                          type="password"
                          placeholder="Enter your decryption key" 
                          value={encryptionKey}
                          onChange={(e) => setEncryptionKey(e.target.value)}
                        />
                      </div>
                    </div>
                  )}
                  
                  {isProcessing && (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Decrypting file...</span>
                      </div>
                      <Progress value={70} className="h-2" />
                    </div>
                  )}
                  
                  {keyVerified && encryptedFile && (
                    <Alert className="border-green-500 bg-green-50">
                      <Shield className="h-4 w-4 text-green-500" />
                      <AlertTitle className="text-green-600">File Successfully Decrypted</AlertTitle>
                      <AlertDescription className="text-green-600">
                        The file has been securely decrypted and is now available for viewing.
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  {!keyVerified && encryptedFile && encryptionKey && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Key Not Verified</AlertTitle>
                      <AlertDescription>
                        Please provide a valid decryption key to access this file.
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="flex justify-between">
                    <Button 
                      variant="outline" 
                      disabled={!encryptedFile || isProcessing}
                      onClick={() => {
                        setEncryptedFile(null);
                        setEncryptionKey("");
                        setKeyVerified(false);
                      }}
                    >
                      Clear
                    </Button>
                    <Button 
                      onClick={handleDecrypt}
                      disabled={!encryptedFile || !encryptionKey || isProcessing}
                    >
                      <Unlock className="mr-2 h-4 w-4" />
                      Decrypt File
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
