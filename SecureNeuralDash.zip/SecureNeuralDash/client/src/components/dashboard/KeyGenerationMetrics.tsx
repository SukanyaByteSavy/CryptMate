import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface KeyMetricsProps {
  keyMetrics?: {
    averageEntropy: number;
    neuralStrength: {
      level: number;
      percentage: number;
      label: string;
    };
    keysGeneratedToday: number;
    totalActiveKeys: number;
    expiringKeys: number;
  };
}

export default function KeyGenerationMetrics({ 
  keyMetrics = {
    averageEntropy: 98.92,
    neuralStrength: {
      level: 4,
      percentage: 85,
      label: "High (Level 4)"
    },
    keysGeneratedToday: 5,
    totalActiveKeys: 7,
    expiringKeys: 2
  }
}: KeyMetricsProps) {
  return (
    <Card>
      <div className="px-4 py-5 sm:px-6 border-b border-slate-200">
        <h3 className="text-lg leading-6 font-medium text-slate-900">Key Generation Metrics</h3>
        <p className="mt-1 max-w-2xl text-sm text-slate-500">AES-256 with neural cryptography</p>
      </div>
      <CardContent className="p-6">
        <dl>
          <div className="grid grid-cols-1 gap-x-4 gap-y-6">
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-slate-500">Average Entropy</dt>
              <dd className="mt-1 text-sm text-slate-900">{keyMetrics.averageEntropy}%</dd>
              <div className="mt-1">
                <Progress value={keyMetrics.averageEntropy} className="h-2 bg-slate-200" />
              </div>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-slate-500">Neural Strength</dt>
              <dd className="mt-1 text-sm text-slate-900">{keyMetrics.neuralStrength.label}</dd>
              <div className="mt-1">
                <Progress value={keyMetrics.neuralStrength.percentage} className="h-2 bg-slate-200" indicatorClassName="bg-secondary" />
              </div>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-slate-500">Keys Generated Today</dt>
              <dd className="mt-1 text-sm text-slate-900">{keyMetrics.keysGeneratedToday}</dd>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-slate-500">Total Active Keys</dt>
              <dd className="mt-1 text-sm text-slate-900">{keyMetrics.totalActiveKeys}</dd>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-slate-500">Expires in next 7 days</dt>
              <dd className="mt-1 text-sm text-slate-900">{keyMetrics.expiringKeys}</dd>
            </div>
          </div>
        </dl>
      </CardContent>
      <div className="bg-slate-50 px-4 py-4 sm:px-6 border-t border-slate-200">
        <a href="#" className="text-sm font-medium text-primary hover:text-primary">View all key metrics</a>
      </div>
    </Card>
  );
}
