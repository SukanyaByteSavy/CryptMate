import { Shield, Key, AlertTriangle, Zap } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatusProps {
  securityStatus?: {
    status: string;
    lastScan: string;
  };
  activeKeys?: {
    count: number;
  };
  threatAlerts?: {
    count: number;
  };
  neuralNetworkStatus?: {
    status: string;
  };
}

export default function StatusOverview({ 
  securityStatus = { status: 'Secured', lastScan: '5 minutes ago' },
  activeKeys = { count: 7 },
  threatAlerts = { count: 2 },
  neuralNetworkStatus = { status: 'Active' }
}: StatusProps) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {/* Security Status Card */}
      <Card>
        <CardContent className="p-0">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                <Shield className="h-6 w-6 text-success" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Security Status</dt>
                  <dd>
                    <div className="text-lg font-medium text-success">{securityStatus.status}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-slate-50 px-5 py-3 border-t">
            <div className="text-sm">
              <a href="#" className="font-medium text-primary hover:text-primary">Last scan: {securityStatus.lastScan}</a>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Keys Card */}
      <Card>
        <CardContent className="p-0">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                <Key className="h-6 w-6 text-primary" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Active Keys</dt>
                  <dd>
                    <div className="text-lg font-medium text-slate-900">{activeKeys.count}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-slate-50 px-5 py-3 border-t">
            <div className="text-sm">
              <a href="#" className="font-medium text-primary hover:text-primary">Generate new key</a>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Threat Detection Card */}
      <Card>
        <CardContent className="p-0">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-amber-100 rounded-md p-3">
                <AlertTriangle className="h-6 w-6 text-warning" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Threat Alerts</dt>
                  <dd>
                    <div className="text-lg font-medium text-slate-900">{threatAlerts.count}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-slate-50 px-5 py-3 border-t">
            <div className="text-sm">
              <a href="#" className="font-medium text-primary hover:text-primary">View threats</a>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Neural Network Status */}
      <Card>
        <CardContent className="p-0">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-indigo-100 rounded-md p-3">
                <Zap className="h-6 w-6 text-secondary" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Neural Network</dt>
                  <dd>
                    <div className="text-lg font-medium text-slate-900">{neuralNetworkStatus.status}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-slate-50 px-5 py-3 border-t">
            <div className="text-sm">
              <a href="#" className="font-medium text-primary hover:text-primary">View details</a>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
