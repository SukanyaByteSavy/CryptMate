import { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface LogEntry {
  timestamp: string;
  type: 'command' | 'info' | 'success' | 'error';
  content: string;
}

interface SecurityConsoleProps {
  logs?: LogEntry[];
}

export default function SecurityConsole({ 
  logs = [
    { timestamp: '2023-04-12 09:23:45', type: 'command', content: 'key status --all' },
    { timestamp: '2023-04-12 09:23:46', type: 'info', content: 'Checking status of all encryption keys...' },
    { timestamp: '2023-04-12 09:23:47', type: 'info', content: '7 keys found (5 active, 2 expiring soon, 0 expired)' },
    { timestamp: '2023-04-12 09:23:48', type: 'info', content: 'Neural network integrity: 100%' },
    { timestamp: '2023-04-12 09:23:49', type: 'info', content: 'Last threat scan: 2023-04-12 08:45:21 [CLEAN]' },
    { timestamp: '2023-04-12 09:24:10', type: 'command', content: 'neural status' },
    { timestamp: '2023-04-12 09:24:11', type: 'info', content: 'Neural network status: ACTIVE' },
    { timestamp: '2023-04-12 09:24:12', type: 'info', content: 'Network type: Recursive Neural Cryptography' },
    { timestamp: '2023-04-12 09:24:13', type: 'info', content: 'Training iterations: 15,432' },
    { timestamp: '2023-04-12 09:24:14', type: 'info', content: 'Encryption strength: HIGH (Level 4)' },
    { timestamp: '2023-04-12 09:24:15', type: 'info', content: 'Last update: 2023-04-11 23:17:42' },
    { timestamp: '2023-04-12 09:25:30', type: 'command', content: 'encrypt-file /path/to/secret.txt --method=aes-neural' },
    { timestamp: '2023-04-12 09:25:31', type: 'info', content: 'Starting encryption process...' },
    { timestamp: '2023-04-12 09:25:32', type: 'info', content: 'Using AES-256 with neural enhancement' },
    { timestamp: '2023-04-12 09:25:33', type: 'info', content: 'Entropy estimation: 99.1%' },
    { timestamp: '2023-04-12 09:25:34', type: 'success', content: 'File encrypted successfully: secret.txt.enc' },
  ]
}: SecurityConsoleProps) {
  const [consoleInput, setConsoleInput] = useState("");
  const [localLogs, setLocalLogs] = useState<LogEntry[]>(logs);
  const consoleEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to the bottom when logs update
  useEffect(() => {
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [localLogs]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!consoleInput.trim()) return;

    // Add the command to the logs
    const newCommand: LogEntry = {
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      type: 'command',
      content: consoleInput
    };

    // Simulate a response based on the command
    let responseEntries: LogEntry[] = [];
    
    if (consoleInput.includes('key')) {
      responseEntries = [
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: 'Processing key command...' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'success', content: 'Key operation completed successfully.' }
      ];
    } else if (consoleInput.includes('encrypt')) {
      responseEntries = [
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: 'Starting encryption...' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: 'Using AES-256 encryption with neural enhancement' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'success', content: 'Encryption completed with 99.2% entropy.' }
      ];
    } else if (consoleInput.includes('decrypt')) {
      responseEntries = [
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: 'Starting decryption...' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'success', content: 'File decrypted successfully.' }
      ];
    } else if (consoleInput.includes('neural')) {
      responseEntries = [
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: 'Neural network status: ACTIVE' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: 'Current strength rating: HIGH' }
      ];
    } else if (consoleInput.includes('help')) {
      responseEntries = [
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: 'Available commands:' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: '  key status --all : Check all keys' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: '  neural status : Check neural network' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: '  encrypt-file [path] : Encrypt a file' },
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'info', content: '  decrypt-file [path] : Decrypt a file' }
      ];
    } else {
      responseEntries = [
        { timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19), type: 'error', content: 'Unknown command. Type "help" for available commands.' }
      ];
    }

    setLocalLogs([...localLogs, newCommand, ...responseEntries]);
    setConsoleInput("");
  };

  return (
    <Card className="mt-8">
      <div className="px-4 py-5 sm:px-6 border-b border-slate-200">
        <h3 className="text-lg leading-6 font-medium text-slate-900">Security Console</h3>
        <p className="mt-1 max-w-2xl text-sm text-slate-500">Advanced encryption commands and logs</p>
      </div>
      <div className="bg-slate-900 p-4 h-64 overflow-auto font-mono text-sm text-slate-300">
        {localLogs.map((log, index) => (
          <div key={index} className="mb-2">
            {log.type === 'command' ? (
              <div>
                <span className="text-green-400">system@neurocrypt:~$</span> <span className="text-white">{log.content}</span>
              </div>
            ) : (
              <div className={`
                ${log.type === 'info' ? 'text-slate-300' : ''}
                ${log.type === 'success' ? 'text-green-400' : ''}
                ${log.type === 'error' ? 'text-red-400' : ''}
              `}>
                [{log.type.toUpperCase()}] {log.content}
              </div>
            )}
          </div>
        ))}
        <div ref={consoleEndRef} />
        <form onSubmit={handleSubmit} className="mt-2 flex">
          <span className="text-green-400 mr-2">system@neurocrypt:~$</span>
          <input
            type="text"
            value={consoleInput}
            onChange={(e) => setConsoleInput(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-white"
            placeholder="Type a command (try 'help')..."
          />
        </form>
      </div>
    </Card>
  );
}
