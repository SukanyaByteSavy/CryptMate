import { useEffect, useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface EntropyVisualizationProps {
  entropyData?: {
    dates: string[];
    aesData: number[];
    neuralData: number[];
  };
  className?: string;
}

export default function EntropyVisualization({ 
  entropyData = {
    dates: ['Apr 6', 'Apr 7', 'Apr 8', 'Apr 9', 'Apr 10', 'Apr 11', 'Apr 12'],
    aesData: [97.8, 98.1, 97.9, 98.2, 98.0, 98.3, 98.2],
    neuralData: [98.5, 98.7, 98.6, 98.9, 99.0, 99.1, 99.2]
  },
  className 
}: EntropyVisualizationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<any>(null);
  const [timeRange, setTimeRange] = useState("7");
  
  // Function to cleanup chart instance
  const destroyChart = () => {
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
      chartInstanceRef.current = null;
    }
  };
  
  useEffect(() => {
    // Load Chart.js script if not already loaded
    if (!(window as any).Chart && !document.getElementById('chartjs-script')) {
      const script = document.createElement('script');
      script.id = 'chartjs-script';
      script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
      script.async = true;
      script.onload = initChart;
      document.body.appendChild(script);
    } else {
      // Chart.js is already loaded, initialize chart
      initChart();
    }
    
    function initChart() {
      const ctx = canvasRef.current?.getContext('2d');
      if (!ctx) return;
      
      // Clean up existing chart if it exists
      destroyChart();
      
      const Chart = (window as any).Chart;
      if (!Chart) return;
      
      // Create new chart instance
      chartInstanceRef.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels: entropyData.dates,
          datasets: [
            {
              label: 'AES-256',
              backgroundColor: 'rgba(14, 165, 233, 0.1)',
              borderColor: '#0ea5e9',
              data: entropyData.aesData,
              tension: 0.3,
              fill: true
            },
            {
              label: 'Neural Enhanced',
              backgroundColor: 'rgba(99, 102, 241, 0.1)',
              borderColor: '#6366f1',
              data: entropyData.neuralData,
              tension: 0.3,
              fill: true
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              mode: 'index',
              intersect: false
            }
          },
          scales: {
            x: {
              grid: {
                display: false
              }
            },
            y: {
              min: 97,
              max: 100,
              ticks: {
                callback: function(value: number) {
                  return value + '%';
                }
              }
            }
          }
        }
      });
    }
    
    // Clean up on component unmount
    return () => {
      destroyChart();
    };
  }, [entropyData]);

  return (
    <Card className={cn(className)}>
      <div className="px-4 py-5 sm:px-6 border-b border-slate-200">
        <h3 className="text-lg leading-6 font-medium text-slate-900">Key Entropy Visualization</h3>
        <p className="mt-1 max-w-2xl text-sm text-slate-500">Neural-network enhanced encryption strength metrics</p>
      </div>
      <CardContent className="p-6">
        <div className="h-64">
          <canvas ref={canvasRef}></canvas>
        </div>
      </CardContent>
      <div className="bg-slate-50 px-4 py-4 sm:px-6 border-t border-slate-200">
        <div className="flex items-center justify-between text-sm">
          <div className="flex space-x-4">
            <div className="flex items-center">
              <span className="h-3 w-3 bg-primary rounded-full mr-2"></span>
              <span className="text-slate-600">AES-256</span>
            </div>
            <div className="flex items-center">
              <span className="h-3 w-3 bg-secondary rounded-full mr-2"></span>
              <span className="text-slate-600">Neural Enhanced</span>
            </div>
          </div>
          <div>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 3 months</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </Card>
  );
}
