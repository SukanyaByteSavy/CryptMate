import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Key } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface KeyData {
  id: string;
  type: string;
  created: string;
  expires: string;
  entropy: string;
  status: "Active" | "Expiring soon" | "Expired";
}

interface KeyManagementPanelProps {
  keys?: KeyData[];
}

export default function KeyManagementPanel({ 
  keys = [
    {
      id: "AES256_231594",
      type: "Neural enhanced",
      created: "2023-04-12 08:45:21",
      expires: "2023-05-12 08:45:21",
      entropy: "98.7%",
      status: "Active"
    },
    {
      id: "AES256_874521",
      type: "Neural enhanced",
      created: "2023-04-05 14:32:18",
      expires: "2023-05-05 14:32:18",
      entropy: "99.2%",
      status: "Active"
    },
    {
      id: "AES256_653891",
      type: "Standard",
      created: "2023-03-20 09:12:45",
      expires: "2023-04-20 09:12:45",
      entropy: "97.8%",
      status: "Expiring soon"
    },
    {
      id: "AES256_142857",
      type: "Neural enhanced",
      created: "2023-03-15 17:05:33",
      expires: "2023-04-15 17:05:33",
      entropy: "98.5%",
      status: "Expiring soon"
    }
  ] as KeyData[]
}: KeyManagementPanelProps) {
  const [activeTab, setActiveTab] = useState("all-keys");
  const { toast } = useToast();

  const handleGenerateKey = async () => {
    try {
      await apiRequest('POST', '/api/keys', { type: 'AES-256-Neural' });
      queryClient.invalidateQueries({ queryKey: ['/api/keys/all'] });
      toast({
        title: "Key generated successfully",
        description: "A new AES-256 Neural enhanced key has been created",
      });
    } catch (error) {
      toast({
        title: "Error generating key",
        description: "There was a problem generating the key",
        variant: "destructive",
      });
    }
  };

  const statusClasses = {
    "Active": "bg-green-100 text-green-800",
    "Expiring soon": "bg-amber-100 text-amber-800",
    "Expired": "bg-red-100 text-red-800"
  };

  return (
    <Card className="mt-8">
      <div className="px-4 py-5 sm:px-6 border-b border-slate-200">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg leading-6 font-medium text-slate-900">Advanced Key Management</h3>
            <p className="mt-1 max-w-2xl text-sm text-slate-500">Manage encryption keys with neural network enhancement</p>
          </div>
          <div>
            <Button onClick={handleGenerateKey}>
              Generate New Key
            </Button>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="border-b border-slate-200 -mb-px">
            <TabsTrigger value="all-keys" className="border-primary text-primary border-b-2 whitespace-nowrap py-2 px-1 text-sm font-medium">
              All Keys
            </TabsTrigger>
            <TabsTrigger value="neural-network" className="border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 whitespace-nowrap py-2 px-1 text-sm font-medium">
              Neural Network
            </TabsTrigger>
            <TabsTrigger value="security-logs" className="border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 whitespace-nowrap py-2 px-1 text-sm font-medium">
              Security Logs
            </TabsTrigger>
            <TabsTrigger value="ai-integration" className="border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 whitespace-nowrap py-2 px-1 text-sm font-medium">
              AI Integration
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="all-keys" className="mt-0">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Key ID</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Created</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Expires</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Entropy</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {keys.map((key, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center bg-blue-100 rounded-md">
                            <Key className="h-6 w-6 text-primary" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-slate-900">{key.id}</div>
                            <div className="text-sm text-slate-500">{key.type}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-slate-900">{key.created}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-slate-900">{key.expires}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-slate-900">{key.entropy}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClasses[key.status]}`}>
                          {key.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <a href="#" className="text-primary hover:text-primary mr-2">View</a>
                        <span className="mx-2 text-slate-300">|</span>
                        <a href="#" className="text-slate-600 hover:text-slate-900">Revoke</a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
          
          <TabsContent value="neural-network">
            <div className="p-4 text-center text-slate-500">
              Neural network configuration and monitoring will be displayed here.
            </div>
          </TabsContent>
          
          <TabsContent value="security-logs">
            <div className="p-4 text-center text-slate-500">
              Security logs and events will be displayed here.
            </div>
          </TabsContent>
          
          <TabsContent value="ai-integration">
            <div className="p-4 text-center text-slate-500">
              AI integration settings and metrics will be displayed here.
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Card>
  );
}
