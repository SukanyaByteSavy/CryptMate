import { Link, useLocation } from "wouter";
import { Shield, Key, FileText, Network, BarChart, Settings, Home } from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { name: "Dashboard", href: "/", icon: Home },
    { name: "Key Management", href: "/key-management", icon: Key },
    { name: "File Encryption", href: "/file-encryption", icon: FileText },
    { name: "Neural Network", href: "/neural-network", icon: Network },
    { name: "Analytics", href: "/analytics", icon: BarChart },
    { name: "Settings", href: "/settings", icon: Settings },
  ];

  return (
    <div className="flex flex-col w-64 bg-slate-50 border-r border-slate-200">
      <div className="flex items-center justify-center h-16 px-4 border-b border-slate-200">
        <div className="flex items-center">
          <Shield className="h-8 w-8 text-primary" />
          <span className="ml-2 text-xl font-semibold text-slate-900">CryptMate</span>
        </div>
      </div>
      <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
        <nav className="mt-5 flex-1 px-2 space-y-1">
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link 
                key={item.name}
                href={item.href}
                className={cn(
                  isActive
                    ? "bg-white text-slate-900"
                    : "text-slate-600 hover:bg-white hover:text-slate-900",
                  "group flex items-center px-2 py-2 text-sm font-medium rounded-md"
                )}
              >
                <Icon 
                  className="text-slate-500 mr-3 flex-shrink-0 h-6 w-6" 
                  aria-hidden="true" 
                />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="border-t border-slate-200 p-4">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <Avatar>
              <AvatarFallback>AU</AvatarFallback>
            </Avatar>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-slate-900">Admin User</p>
            <p className="text-xs font-medium text-slate-500">Security Admin</p>
          </div>
        </div>
      </div>
    </div>
  );
}
