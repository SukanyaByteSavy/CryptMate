import {
  User, InsertUser,
  EncryptionKey, InsertEncryptionKey,
  EncryptedFile, InsertEncryptedFile,
  SecurityLog, InsertSecurityLog,
  NeuralNetworkStatus, InsertNeuralNetworkStatus,
  SecurityStatus, InsertSecurityStatus
} from "@shared/schema";
import crypto from 'crypto';

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Encryption Key operations
  getAllKeys(): Promise<EncryptionKey[]>;
  getActiveKeys(): Promise<EncryptionKey[]>;
  getExpiringKeys(daysThreshold: number): Promise<EncryptionKey[]>;
  getKeyById(id: number): Promise<EncryptionKey | undefined>;
  getKeyByKeyId(keyId: string): Promise<EncryptionKey | undefined>;
  createKey(key: InsertEncryptionKey): Promise<EncryptionKey>;
  updateKeyStatus(id: number, status: string): Promise<EncryptionKey | undefined>;
  
  // Encrypted File operations
  getAllFiles(): Promise<EncryptedFile[]>;
  getFileById(id: number): Promise<EncryptedFile | undefined>;
  createFile(file: InsertEncryptedFile): Promise<EncryptedFile>;
  
  // Security Log operations
  getAllLogs(): Promise<SecurityLog[]>;
  getLatestLogs(limit: number): Promise<SecurityLog[]>;
  createLog(log: InsertSecurityLog): Promise<SecurityLog>;
  
  // Neural Network operations
  getNeuralNetworkStatus(): Promise<NeuralNetworkStatus | undefined>;
  updateNeuralNetworkStatus(status: InsertNeuralNetworkStatus): Promise<NeuralNetworkStatus | undefined>;
  
  // Security Status operations
  getSecurityStatus(): Promise<SecurityStatus | undefined>;
  updateSecurityStatus(status: InsertSecurityStatus): Promise<SecurityStatus | undefined>;
  
  // Analytics
  getKeyMetrics(): Promise<any>;
  getEntropyData(days: number): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private encryptionKeys: Map<number, EncryptionKey>;
  private encryptedFiles: Map<number, EncryptedFile>;
  private securityLogs: Map<number, SecurityLog>;
  private neuralNetworkStatusData: NeuralNetworkStatus | undefined;
  private securityStatusData: SecurityStatus | undefined;
  
  private userCurrentId: number;
  private keyCurrentId: number;
  private fileCurrentId: number;
  private logCurrentId: number;
  
  constructor() {
    this.users = new Map();
    this.encryptionKeys = new Map();
    this.encryptedFiles = new Map();
    this.securityLogs = new Map();
    
    this.userCurrentId = 1;
    this.keyCurrentId = 1;
    this.fileCurrentId = 1;
    this.logCurrentId = 1;
    
    // Initialize with default data
    this.initializeDefaultData();
  }
  
  private initializeDefaultData() {
    // Add default admin user
    this.createUser({
      username: 'admin',
      password: 'password123',
      role: 'admin'
    });
    
    // Add some encryption keys
    const now = new Date();
    
    // Active keys
    this.createKey({
      keyId: 'AES256_231594',
      keyType: 'Neural enhanced',
      entropy: '98.7%',
      status: 'Active',
      expiresAt: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      createdBy: 1
    });
    
    this.createKey({
      keyId: 'AES256_874521',
      keyType: 'Neural enhanced',
      entropy: '99.2%',
      status: 'Active',
      expiresAt: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      createdBy: 1
    });
    
    // Expiring soon keys
    this.createKey({
      keyId: 'AES256_653891',
      keyType: 'Standard',
      entropy: '97.8%',
      status: 'Expiring soon',
      expiresAt: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
      createdBy: 1
    });
    
    this.createKey({
      keyId: 'AES256_142857',
      keyType: 'Neural enhanced',
      entropy: '98.5%',
      status: 'Expiring soon',
      expiresAt: new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      createdBy: 1
    });
    
    // Add some security logs
    this.createLog({
      eventType: 'key_generated',
      description: 'Generated new AES-256 Neural enhanced key: AES256_231594',
      ipAddress: '192.168.1.1',
      userId: 1
    });
    
    this.createLog({
      eventType: 'file_encrypted',
      description: 'File encrypted: document.pdf using key AES256_231594',
      ipAddress: '192.168.1.1',
      userId: 1
    });
    
    // Set neural network status
    this.neuralNetworkStatusData = {
      id: 1,
      status: 'Active',
      networkType: 'Recursive Neural Cryptography',
      trainingIterations: 15432,
      encryptionStrength: 'HIGH (Level 4)',
      lastUpdated: new Date()
    };
    
    // Set security status
    this.securityStatusData = {
      id: 1,
      status: 'Secured',
      threatLevel: 'Low',
      lastScan: new Date(),
      activeAlerts: 2
    };
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }
  
  // Encryption Key operations
  async getAllKeys(): Promise<EncryptionKey[]> {
    return Array.from(this.encryptionKeys.values());
  }
  
  async getActiveKeys(): Promise<EncryptionKey[]> {
    return Array.from(this.encryptionKeys.values()).filter(
      (key) => key.status === 'Active'
    );
  }
  
  async getExpiringKeys(daysThreshold: number): Promise<EncryptionKey[]> {
    const thresholdDate = new Date();
    thresholdDate.setDate(thresholdDate.getDate() + daysThreshold);
    
    return Array.from(this.encryptionKeys.values()).filter(
      (key) => key.status === 'Active' && key.expiresAt <= thresholdDate
    );
  }
  
  async getKeyById(id: number): Promise<EncryptionKey | undefined> {
    return this.encryptionKeys.get(id);
  }
  
  async getKeyByKeyId(keyId: string): Promise<EncryptionKey | undefined> {
    return Array.from(this.encryptionKeys.values()).find(
      (key) => key.keyId === keyId
    );
  }
  
  async createKey(insertKey: InsertEncryptionKey): Promise<EncryptionKey> {
    const id = this.keyCurrentId++;
    const now = new Date();
    const key: EncryptionKey = { ...insertKey, id, createdAt: now };
    this.encryptionKeys.set(id, key);
    
    // Add a security log for the key generation
    this.createLog({
      eventType: 'key_generated',
      description: `Generated new ${insertKey.keyType} key: ${insertKey.keyId}`,
      userId: insertKey.createdBy,
      ipAddress: '127.0.0.1'
    });
    
    return key;
  }
  
  async updateKeyStatus(id: number, status: string): Promise<EncryptionKey | undefined> {
    const key = this.encryptionKeys.get(id);
    if (!key) return undefined;
    
    const updatedKey = { ...key, status };
    this.encryptionKeys.set(id, updatedKey);
    
    // Add a security log for the key status update
    this.createLog({
      eventType: 'key_updated',
      description: `Updated key ${key.keyId} status to ${status}`,
      userId: key.createdBy,
      ipAddress: '127.0.0.1'
    });
    
    return updatedKey;
  }
  
  // Encrypted File operations
  async getAllFiles(): Promise<EncryptedFile[]> {
    return Array.from(this.encryptedFiles.values());
  }
  
  async getFileById(id: number): Promise<EncryptedFile | undefined> {
    return this.encryptedFiles.get(id);
  }
  
  async createFile(insertFile: InsertEncryptedFile): Promise<EncryptedFile> {
    const id = this.fileCurrentId++;
    const now = new Date();
    const file: EncryptedFile = { ...insertFile, id, createdAt: now };
    this.encryptedFiles.set(id, file);
    
    // Add a security log for the file encryption
    this.createLog({
      eventType: 'file_encrypted',
      description: `File encrypted: ${insertFile.originalFilename} using key ID ${insertFile.encryptionKeyId}`,
      userId: insertFile.createdBy,
      ipAddress: '127.0.0.1'
    });
    
    return file;
  }
  
  // Security Log operations
  async getAllLogs(): Promise<SecurityLog[]> {
    return Array.from(this.securityLogs.values());
  }
  
  async getLatestLogs(limit: number): Promise<SecurityLog[]> {
    return Array.from(this.securityLogs.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }
  
  async createLog(insertLog: InsertSecurityLog): Promise<SecurityLog> {
    const id = this.logCurrentId++;
    const now = new Date();
    const log: SecurityLog = { ...insertLog, id, timestamp: now };
    this.securityLogs.set(id, log);
    return log;
  }
  
  // Neural Network operations
  async getNeuralNetworkStatus(): Promise<NeuralNetworkStatus | undefined> {
    return this.neuralNetworkStatusData;
  }
  
  async updateNeuralNetworkStatus(status: InsertNeuralNetworkStatus): Promise<NeuralNetworkStatus | undefined> {
    if (!this.neuralNetworkStatusData) {
      const id = 1;
      const lastUpdated = new Date();
      this.neuralNetworkStatusData = { ...status, id, lastUpdated };
    } else {
      this.neuralNetworkStatusData = { 
        ...this.neuralNetworkStatusData, 
        ...status, 
        lastUpdated: new Date() 
      };
    }
    
    return this.neuralNetworkStatusData;
  }
  
  // Security Status operations
  async getSecurityStatus(): Promise<SecurityStatus | undefined> {
    return this.securityStatusData;
  }
  
  async updateSecurityStatus(status: InsertSecurityStatus): Promise<SecurityStatus | undefined> {
    if (!this.securityStatusData) {
      const id = 1;
      const lastScan = new Date();
      this.securityStatusData = { ...status, id, lastScan };
    } else {
      this.securityStatusData = { 
        ...this.securityStatusData, 
        ...status, 
        lastScan: new Date() 
      };
    }
    
    return this.securityStatusData;
  }
  
  // Analytics
  async getKeyMetrics(): Promise<any> {
    const totalKeys = this.encryptionKeys.size;
    const activeKeys = (await this.getActiveKeys()).length;
    const expiringKeys = (await this.getExpiringKeys(7)).length;
    
    // Calculate average entropy (removing the % sign and converting to number)
    const entropyValues = Array.from(this.encryptionKeys.values())
      .map(key => parseFloat(key.entropy.replace('%', '')));
    
    const averageEntropy = entropyValues.length > 0 
      ? entropyValues.reduce((sum, value) => sum + value, 0) / entropyValues.length
      : 0;
    
    // Get keys generated today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const keysGeneratedToday = Array.from(this.encryptionKeys.values())
      .filter(key => {
        const keyDate = new Date(key.createdAt);
        keyDate.setHours(0, 0, 0, 0);
        return keyDate.getTime() === today.getTime();
      }).length;
    
    return {
      totalKeys,
      activeKeys,
      expiringKeys,
      averageEntropy,
      keysGeneratedToday,
      neuralStrength: {
        level: 4,
        percentage: 85,
        label: "High (Level 4)"
      }
    };
  }
  
  async getEntropyData(days: number): Promise<any> {
    // Generate sample entropy data for the past [days] days
    const dates: string[] = [];
    const aesData: number[] = [];
    const neuralData: number[] = [];
    
    const today = new Date();
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const month = monthNames[date.getMonth()];
      const day = date.getDate();
      
      dates.push(`${month} ${day}`);
      
      // Generate slightly varying entropy values
      const aesBase = 97.8;
      const neuralBase = 98.5;
      
      // Add some random variation but ensure neural is always higher
      const rand = () => (Math.random() * 0.5) - 0.1;
      
      const aesValue = aesBase + rand();
      const neuralValue = neuralBase + rand() + 0.6; // Neural should be consistently higher
      
      aesData.push(parseFloat(aesValue.toFixed(1)));
      neuralData.push(parseFloat(neuralValue.toFixed(1)));
    }
    
    return {
      dates,
      aesData,
      neuralData
    };
  }
}

export const storage = new MemStorage();
