import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import crypto from 'crypto';

export async function registerRoutes(app: Express): Promise<Server> {
  // Security Status API
  app.get('/api/security/status', async (req: Request, res: Response) => {
    const securityStatus = await storage.getSecurityStatus();
    
    if (!securityStatus) {
      return res.status(404).json({ message: 'Security status not found' });
    }
    
    // Format the lastScan time to a relative time string
    const lastScanTime = new Date(securityStatus.lastScan).getTime();
    const now = Date.now();
    const diffMinutes = Math.floor((now - lastScanTime) / (1000 * 60));
    
    let lastScan = '';
    if (diffMinutes < 1) {
      lastScan = 'just now';
    } else if (diffMinutes < 60) {
      lastScan = `${diffMinutes} minutes ago`;
    } else if (diffMinutes < 24 * 60) {
      const hours = Math.floor(diffMinutes / 60);
      lastScan = `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
    } else {
      const days = Math.floor(diffMinutes / (24 * 60));
      lastScan = `${days} ${days === 1 ? 'day' : 'days'} ago`;
    }
    
    res.json({
      status: securityStatus.status,
      threatLevel: securityStatus.threatLevel,
      lastScan: lastScan,
      activeAlerts: securityStatus.activeAlerts
    });
  });
  
  // Active Keys API
  app.get('/api/keys/active', async (req: Request, res: Response) => {
    const activeKeys = await storage.getActiveKeys();
    res.json({ count: activeKeys.length });
  });
  
  // Threat Alerts API
  app.get('/api/security/threats', async (req: Request, res: Response) => {
    const securityStatus = await storage.getSecurityStatus();
    res.json({ count: securityStatus ? securityStatus.activeAlerts : 0 });
  });
  
  // Neural Network Status API
  app.get('/api/neural/status', async (req: Request, res: Response) => {
    const neuralStatus = await storage.getNeuralNetworkStatus();
    
    if (!neuralStatus) {
      return res.status(404).json({ message: 'Neural network status not found' });
    }
    
    res.json({ status: neuralStatus.status });
  });
  
  // Key Entropy API
  app.get('/api/keys/entropy', async (req: Request, res: Response) => {
    const days = parseInt(req.query.days as string) || 7;
    const entropyData = await storage.getEntropyData(days);
    res.json(entropyData);
  });
  
  // Key Metrics API
  app.get('/api/keys/metrics', async (req: Request, res: Response) => {
    const metrics = await storage.getKeyMetrics();
    res.json(metrics);
  });
  
  // All Keys API
  app.get('/api/keys/all', async (req: Request, res: Response) => {
    const allKeys = await storage.getAllKeys();
    
    // Format the keys for the frontend
    const formattedKeys = allKeys.map(key => ({
      id: key.keyId,
      type: key.keyType,
      created: new Date(key.createdAt).toLocaleString(),
      expires: new Date(key.expiresAt).toLocaleString(),
      entropy: key.entropy,
      status: key.status
    }));
    
    res.json(formattedKeys);
  });
  
  // Console Logs API
  app.get('/api/logs/console', async (req: Request, res: Response) => {
    const limit = parseInt(req.query.limit as string) || 15;
    const logs = await storage.getLatestLogs(limit);
    
    // Format logs for the console UI
    const formattedLogs = logs.map(log => {
      let type = 'info';
      
      if (log.eventType.includes('generated') || log.eventType.includes('created')) {
        type = 'success';
      } else if (log.eventType.includes('error') || log.eventType.includes('failed')) {
        type = 'error';
      }
      
      return {
        timestamp: new Date(log.timestamp).toLocaleString(),
        type,
        content: log.description
      };
    });
    
    // Add some simulated command entries
    const commandLogs = [
      {
        timestamp: new Date(Date.now() - 100000).toLocaleString(),
        type: 'command',
        content: 'key status --all'
      },
      {
        timestamp: new Date(Date.now() - 50000).toLocaleString(),
        type: 'command',
        content: 'neural status'
      },
      {
        timestamp: new Date(Date.now() - 30000).toLocaleString(),
        type: 'command',
        content: 'encrypt-file /path/to/secret.txt --method=aes-neural'
      }
    ];
    
    // Combine and sort by timestamp (most recent last)
    const allLogs = [...formattedLogs, ...commandLogs].sort((a, b) => {
      return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
    });
    
    res.json(allLogs.slice(-limit));
  });
  
  // Generate Key API
  app.post('/api/keys', async (req: Request, res: Response) => {
    const { type } = req.body;
    
    try {
      // Generate a unique key ID
      const keyId = `AES256_${Math.floor(Math.random() * 1000000)}`;
      
      // Generate a random entropy value
      const entropy = (98.0 + (Math.random() * 2)).toFixed(1) + '%';
      
      // Set expiry date to 30 days from now
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30);
      
      const newKey = await storage.createKey({
        keyId,
        keyType: type || 'AES-256 Neural Enhanced',
        entropy,
        status: 'Active',
        expiresAt,
        createdBy: 1 // Default admin user
      });
      
      res.status(201).json(newKey);
    } catch (error) {
      res.status(500).json({ message: 'Failed to generate key', error });
    }
  });
  
  // Encrypt File API
  app.post('/api/files/encrypt', async (req: Request, res: Response) => {
    const { filename, keyId, method } = req.body;
    
    if (!filename || !keyId || !method) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
    
    try {
      // Find the key
      const key = await storage.getKeyByKeyId(keyId);
      
      if (!key) {
        return res.status(404).json({ message: 'Encryption key not found' });
      }
      
      // Generate encrypted filename
      const encryptedFilename = `${filename}.enc`;
      
      // Create file record
      const file = await storage.createFile({
        filename: encryptedFilename,
        originalFilename: filename,
        encryptionKeyId: key.id,
        encryptionMethod: method,
        fileSize: Math.floor(Math.random() * 1000000), // Mock file size
        createdBy: 1 // Default admin user
      });
      
      res.status(201).json(file);
    } catch (error) {
      res.status(500).json({ message: 'Failed to encrypt file', error });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
