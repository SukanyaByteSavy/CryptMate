import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Encryption Key model
export const encryptionKeys = pgTable("encryption_keys", {
  id: serial("id").primaryKey(),
  keyId: text("key_id").notNull().unique(),
  keyType: text("key_type").notNull(), // AES-256, Neural Enhanced, etc.
  entropy: text("entropy").notNull(),
  status: text("status").notNull().default("Active"), // Active, Expired, Revoked
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  createdBy: integer("created_by").references(() => users.id),
});

// Encrypted File model
export const encryptedFiles = pgTable("encrypted_files", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalFilename: text("original_filename").notNull(),
  encryptionKeyId: integer("encryption_key_id").references(() => encryptionKeys.id),
  encryptionMethod: text("encryption_method").notNull(),
  fileSize: integer("file_size").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  createdBy: integer("created_by").references(() => users.id),
});

// Security Log model
export const securityLogs = pgTable("security_logs", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(), // key_generated, file_encrypted, file_decrypted, etc.
  description: text("description").notNull(),
  ipAddress: text("ip_address"),
  userId: integer("user_id").references(() => users.id),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Neural Network Status model
export const neuralNetworkStatus = pgTable("neural_network_status", {
  id: serial("id").primaryKey(),
  status: text("status").notNull(), // Active, Training, Offline
  networkType: text("network_type").notNull(),
  trainingIterations: integer("training_iterations").notNull(),
  encryptionStrength: text("encryption_strength").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// Security Status model
export const securityStatus = pgTable("security_status", {
  id: serial("id").primaryKey(),
  status: text("status").notNull(), // Secured, Alert, Compromised
  threatLevel: text("threat_level").notNull().default("Low"), // Low, Medium, High
  lastScan: timestamp("last_scan").notNull().defaultNow(),
  activeAlerts: integer("active_alerts").notNull().default(0),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
});

export const insertEncryptionKeySchema = createInsertSchema(encryptionKeys).pick({
  keyId: true,
  keyType: true,
  entropy: true,
  status: true,
  expiresAt: true,
  createdBy: true,
});

export const insertEncryptedFileSchema = createInsertSchema(encryptedFiles).pick({
  filename: true,
  originalFilename: true,
  encryptionKeyId: true,
  encryptionMethod: true,
  fileSize: true,
  createdBy: true,
});

export const insertSecurityLogSchema = createInsertSchema(securityLogs).pick({
  eventType: true,
  description: true,
  ipAddress: true,
  userId: true,
});

export const insertNeuralNetworkStatusSchema = createInsertSchema(neuralNetworkStatus).pick({
  status: true,
  networkType: true,
  trainingIterations: true,
  encryptionStrength: true,
});

export const insertSecurityStatusSchema = createInsertSchema(securityStatus).pick({
  status: true,
  threatLevel: true,
  activeAlerts: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertEncryptionKey = z.infer<typeof insertEncryptionKeySchema>;
export type EncryptionKey = typeof encryptionKeys.$inferSelect;

export type InsertEncryptedFile = z.infer<typeof insertEncryptedFileSchema>;
export type EncryptedFile = typeof encryptedFiles.$inferSelect;

export type InsertSecurityLog = z.infer<typeof insertSecurityLogSchema>;
export type SecurityLog = typeof securityLogs.$inferSelect;

export type InsertNeuralNetworkStatus = z.infer<typeof insertNeuralNetworkStatusSchema>;
export type NeuralNetworkStatus = typeof neuralNetworkStatus.$inferSelect;

export type InsertSecurityStatus = z.infer<typeof insertSecurityStatusSchema>;
export type SecurityStatus = typeof securityStatus.$inferSelect;
